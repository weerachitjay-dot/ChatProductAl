# 📦 คู่มือเพิ่มโปรดักส์ใหม่

## 🎯 วิธีเพิ่มโปรดักส์ใหม่

### ขั้นตอนที่ 1: เปิดไฟล์ knowledge-base.js

เปิดไฟล์: `/Users/weerachitbuaim/Documents/coppy-web/knowledge-base.js`

### ขั้นตอนที่ 2: เพิ่มข้อมูลโปรดักส์

หาส่วน `export const INSURANCE_PRODUCTS = {` (บรรทัดที่ 4) แล้วเพิ่มโปรดักส์ใหม่:

```javascript
export const INSURANCE_PRODUCTS = {
  // โปรดักส์เดิม...
  
  // ⭐ เพิ่มโปรดักส์ใหม่ที่นี่
  productNewName: {
    name: 'ชื่อแบบประกันภาษาไทย',
    code: 'PRODUCT_CODE', // ตัวพิมพ์ใหญ่, ใช้ _ คั่น
    description: 'คำอธิบายสั้นๆ',
    ageRange: { min: 18, max: 70 }, // อายุต่ำสุด-สูงสุด
    coverage: 'ครอบคลุมถึงอายุ 99 ปี', // รายละเอียดความคุ้มครอง
    benefits: [
      'ประโยชน์ข้อที่ 1',
      'ประโยชน์ข้อที่ 2',
      'ประโยชน์ข้อที่ 3',
      'ประโยชน์ข้อที่ 4'
    ],
    url: 'https://product.thailife.com/...' // (optional) ลิงก์ข้อมูลเพิ่มเติม
  }
};
```

### ตัวอย่างเต็ม:

```javascript
export const INSURANCE_PRODUCTS = {
  seniorCare: {
    name: 'สูงวัยไร้กังวล (เพื่อผู้สูงอายุ)',
    code: 'SENIOR_CARE',
    description: 'ประกันชีวิตสำหรับผู้สูงอายุ',
    ageRange: { min: 50, max: 75 },
    coverage: 'ครอบคลุมถึงอายุ 99 ปี',
    benefits: [
      'รับเงินคืนทุกปีตลอดสัญญา',
      'คุ้มครองกรณีเสียชีวิตทุกกรณี',
      'ไม่ต้องตรวจสุขภาพ',
      'รับเงินครบกำหนดสัญญา'
    ]
  },
  
  // ⭐ เพิ่มใหม่
  healthProtect: {
    name: 'สุขภาพเต็มร้อย',
    code: 'HEALTH_PROTECT',
    description: 'ประกันสุขภาพแบบครอบคลุม',
    ageRange: { min: 18, max: 65 },
    coverage: 'ครอบคลุมถึงอายุ 85 ปี',
    benefits: [
      'คุ้มครองค่ารักษาพยาบาล',
      'ค่าห้องพักวันละ 5,000 บาท',
      'ผ่าตัดได้ไม่จำกัด',
      'เบี้ยถูกกว่าประกันสุขภาพทั่วไป'
    ],
    url: 'https://product.thailife.com/health-protect'
  }
};
```

---

### ขั้นตอนที่ 3: เพิ่มใน HTML (สำหรับ Dropdown)

เปิดไฟล์: `/Users/weerachitbuaim/Documents/coppy-web/index.html`

หาส่วน `<select id="productFocus" multiple size="4">` (ประมาณบรรทัดที่ 230) แล้วเพิ่ม:

```html
<select id="productFocus" multiple size="4">
  <option value="all">ทุกแบบประกัน (แนะนำทั่วไป)</option>
  <option value="SENIOR_CARE">สูงวัยไร้กังวล</option>
  <option value="SAVING_HAPPY">ออมยาวคุ้มทวีคูณ</option>
  <option value="LEGACY_FIT_99">เลกาซี ฟิต 99</option>
  <option value="MONEY_SAVING">มันนี่ เซฟวิ่ง 14/6</option>
  
  <!-- ⭐ เพิ่มที่นี่ -->
  <option value="HEALTH_PROTECT">สุขภาพเต็มร้อย</option>
</select>
```

**สำคัญ:** `value` ต้องตรงกับ `code` ที่ใส่ใน knowledge-base.js

---

### ขั้นตอนที่ 4: เพิ่มใน Sidebar (Product List)

ในไฟล์ `index.html` เดิม หาส่วน Products Quick Reference (ประมาณบรรทัดที่ 180):

```html
<div class="products-list">
  <div class="product-item">
    <div class="product-name">สูงวัยไร้กังวล</div>
    <div class="product-age">อายุ 50-75 ปี</div>
  </div>
  <!-- โปรดักส์อื่นๆ -->
  
  <!-- ⭐ เพิ่มที่นี่ -->
  <div class="product-item">
    <div class="product-name">สุขภาพเต็มร้อย</div>
    <div class="product-age">อายุ 18-65 ปี</div>
  </div>
</div>
```

---

### ขั้นตอนที่ 5: ทดสอบ

1. **Refresh หน้าเว็บ** (Cmd+Shift+R)
2. **เปิดตั้งค่า** → ดูว่าโปรดักส์ใหม่ปรากฏใน dropdown หรือไม่
3. **เลือกโปรดักส์ใหม่** → บันทึก
4. **ลองถาม AI** เกี่ยวกับโปรดักส์ใหม่

---

## 📋 Checklist

- [ ] เพิ่มข้อมูลใน `knowledge-base.js`
- [ ] เพิ่ม option ใน `<select id="productFocus">`
- [ ] เพิ่มใน Products List (sidebar)
- [ ] Refresh หน้าเว็บ
- [ ] ทดสอบใช้งาน

---

## 💡 Tips

### 1. ตั้งชื่อ code ให้ดี
```javascript
// ✅ ดี - อ่านง่าย
code: 'HEALTH_PROTECT'
code: 'SENIOR_CARE'

// ❌ ไม่ดี - สับสน
code: 'HP'
code: 'SC'
```

### 2. ประโยชน์ (benefits) ควรเขียนสั้นๆ
```javascript
// ✅ ดี
benefits: [
  'รับเงินคืนทุกปี',
  'ไม่ต้องตรวจสุขภาพ'
]

// ❌ ยาวเกิน
benefits: [
  'จะได้รับเงินคืนทุกปีตลอดสัญญาเป็นจำนวนร้อยละ 5 ของทุนประกัน...'
]
```

### 3. ระบุอายุให้ชัดเจน
```javascript
ageRange: { min: 18, max: 65 }
```

---

## ⚠️ ข้อควรระวัง

1. **`code` ต้องเป็นภาษาอังกฤษ** - ใช้ตัวพิมพ์ใหญ่ทั้งหมด
2. **`code` ต้องไม่ซ้ำ** - แต่ละโปรดักส์ต้องมี code ไม่เหมือนกัน
3. **`value` ใน HTML ต้องตรงกับ `code`** - ถ้าไม่ตรงจะเลือกไม่ได้
4. **Refresh ทุกครั้ง** - หลังแก้ไขต้อง Hard Refresh (Cmd+Shift+R)

---

## 🎨 ตัวอย่างโปรดักส์ครบ

```javascript
export const INSURANCE_PRODUCTS = {
  // 1. ผู้สูงอายุ
  seniorCare: {
    name: 'สูงวัยไร้กังวล',
    code: 'SENIOR_CARE',
    description: 'ประกันชีวิตสำหรับผู้สูงอายุ',
    ageRange: { min: 50, max: 75 },
    coverage: 'ครอบคลุมถึงอายุ 99 ปี',
    benefits: ['รับเงินคืนทุกปี', 'ไม่ต้องตรวจสุขภาพ']
  },
  
  // 2. ออมทรัพย์
  savingPlan: {
    name: 'ออมสบาย รับเงินคืน',
    code: 'SAVING_PLAN',
    description: 'ออมเงินระยะยาว รับเงินคืนทุกปี',
    ageRange: { min: 1, max: 60 },
    coverage: 'ครอบคลุมถึงอายุ 99 ปี',
    benefits: ['รับเงินคืน 5% ต่อปี', 'เบี้ยคุ้มค่า']
  },
  
  // 3. สุขภาพ
  healthCare: {
    name: 'สุขภาพแข็งแรง',
    code: 'HEALTH_CARE',
    description: 'ประกันสุขภาพครอบคลุม',
    ageRange: { min: 18, max: 65 },
    coverage: 'ครอบคลุมถึงอายุ 85 ปี',
    benefits: ['ค่ารักษาพยาบาล', 'ค่าห้องพัก', 'ผ่าตัดไม่จำกัด']
  }
};
```

---

**เพิ่มได้ไม่จำกัด!** 🚀
