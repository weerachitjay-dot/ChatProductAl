
// Simulate the normalizeResponse function
function normalizeResponse(text) {
    if (!text) return text;

    let normalized = text;

    // 1. Collapse multiple newlines/spaces into single newline
    normalized = normalized.replace(/\n\s*\n/g, '\n');

    // Also trim start/end
    normalized = normalized.trim();

    return normalized;
}

const testCases = [
    {
        input: "Line 1\n\n\n.\n\nLine 2",
        expected: "Line 1\n.\nLine 2"
    },
    {
        input: "Line 1\n.\nLine 2",
        expected: "Line 1\n.\nLine 2"
    },
    {
        input: "   Line 1   \n\n   .   \n\n   Line 2   ",
        expected: "Line 1   \n   .   \n   Line 2"
    }
];

let allPassed = true;
testCases.forEach((tc, index) => {
    const output = normalizeResponse(tc.input);
    if (output === tc.expected) {
        console.log(`Test Case ${index + 1}: PASS`);
    } else {
        console.log(`Test Case ${index + 1}: FAIL`);
        console.log(`Expected: ${JSON.stringify(tc.expected)}`);
        console.log(`Actual:   ${JSON.stringify(output)}`);
        allPassed = false;
    }
});

if (!allPassed) process.exit(1);
